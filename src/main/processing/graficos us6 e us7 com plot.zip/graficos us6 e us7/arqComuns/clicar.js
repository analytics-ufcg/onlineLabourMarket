window.onload = function(){
	document.getElementById("bt01").onclick=function(){
		window.location.href = 'index.html';
	}
	
	document.getElementById("bt02").onclick=function(){
		window.location.href = 'grafico02.html';
	}
	
}