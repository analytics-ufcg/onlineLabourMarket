args = commandArgs(TRUE)
source.dir = as.character(args[1])

files = list.files(source.dir, full.names=T, pattern=".txt")

generating.csv.file = function(f) {
  dados = read.table(f, sep=";")
  ag = aggregate(dados$V2, list(dados$V1), sum)
  colnames(ag) = c("timestamp", "Guru")
  nome = f
  nome = gsub(".txt", ".csv", nome)
  write.csv(file=nome, ag, row.names=F, quote=F)
}

iterate.files = function(files) {
  for(f in files) {
    generating.csv.file(f)
  }  
}

iterate.files(files)