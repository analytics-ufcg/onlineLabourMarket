import sys
import onlinelabourmarket
        
if __name__ == '__main__':
    onlinelabourmarket.generateGuruTimeLineFilesFromWorkers(sys.argv[1])
pass
