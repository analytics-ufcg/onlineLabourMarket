import sys
import datetime

arq = open(sys.argv[1],"r")
arqSaida = open(sys.argv[2],"w")


dado = arq.readline()
arqSaida.write(dado)
dado = arq.readline()
valor = -1

for linha in arq.readlines():
    lista = dado.split(",")
    lista2 = linha.split(",")
    if(valor==-1):
        valor = dado.split(",")[1]
    tamp1 = datetime.datetime.fromtimestamp(int(lista[0])).strftime('%Y-%m-%d')
    tamp2 = datetime.datetime.fromtimestamp(int(lista2[0])).strftime('%Y-%m-%d')
    if(tamp1==tamp2):
        valor = lista2[1]
    else:
	    arqSaida.write(lista[0]+","+valor)
	    soma = -1
	    dado = linha

valor = dado.split(",")[1]
arqSaida.write(dado.split(",")[0]+","+valor)
arq.close()
arqSaida.close()