import sys
import datetime

arq = open(sys.argv[1],"r")
arqSaida = open(sys.argv[2],"w")


dado = arq.readline()
soma = int(dado.split(",")[1])

for linha in arq.readlines():
    lista = dado.split(",")
    lista2 = linha.split(",")
    if(soma==-1):
        soma = int(dado.split(",")[1])
    tamp1 = datetime.datetime.fromtimestamp(int(lista[0])).strftime('%Y-%m-%d')
    tamp2 = datetime.datetime.fromtimestamp(int(lista2[0])).strftime('%Y-%m-%d')
    if(tamp1==tamp2):
        soma = soma + int(lista2[1])
    else:
	    arqSaida.write(lista[0]+","+str(soma)+"\n")
	    soma = -1
	    dado = linha

soma = int(dado.split(",")[1])
arqSaida.write(dado.split(",")[0]+","+str(soma)+"\n")
arq.close()
arqSaida.close()