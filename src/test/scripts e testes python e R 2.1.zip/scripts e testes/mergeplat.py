import sys
import datetime

arq = open(sys.argv[1],"r")
arq2 = open(sys.argv[2],"r")
arqSaida = open(sys.argv[3],"w")
linhaTemp = arq2.readline()

t1 = arq.readline()
t2 = linhaTemp
t1 = t1.split(",")
t2 = t2.split(",")
t3 = t1[0]+","+t1[1].replace("\n","")+","+t2[1]
arqSaida.write(t3)

linhaTemp = arq2.readline()

for linha in arq.readlines():
    lista = linhaTemp.split(",")
    lista2 = linha.split(",")
    tamp1 = datetime.datetime.fromtimestamp(int(lista2[0])).strftime('%Y-%m-%d')
    if(lista[0]!=""):
	   tamp2 = datetime.datetime.fromtimestamp(int(lista[0])).strftime('%Y-%m-%d')
    if(tamp2==tamp1):
	   arqSaida.write(lista2[0]+","+lista2[1].replace("\n","")+","+lista[1])
	   linhaTemp = arq2.readline()
    else:
	    arqSaida.write(lista2[0]+","+lista2[1].replace("\n","")+","+"0\n")
		
arq.close()
arq2.close()
arqSaida.close()