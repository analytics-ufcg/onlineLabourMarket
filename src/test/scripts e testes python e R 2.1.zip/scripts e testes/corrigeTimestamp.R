args = commandArgs(T)

dir = args[1]

files = list.files(dir, full.names=T, pattern=".csv")

date.from.timestamp =  function(ts){
  return(strptime(structure(ts, class=c("POSIXt", "POSIXct")), "%Y-%m-%d"))
}

iterate.files = function(files) {
  for(f in files) {
    dados = read.csv(f)
    dados$timestamp = as.numeric(date.from.timestamp(dados$timestamp))
    write.csv(file=f, dados, row.names=F, quote=F)
  }
}

iterate.files(files)