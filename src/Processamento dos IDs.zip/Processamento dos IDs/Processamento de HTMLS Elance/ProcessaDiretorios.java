import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.IOException;

class ProcessaDiretorios{


public static void main(String args[]) throws IOException{

    File diretorio = new File("htmls");
    String[] nomePastas = diretorio.list();
    String separador = "\\";
    ProcessaArquivo processador = new ProcessaArquivo();
    PrintWriter printWriter = new PrintWriter("idsProcessadosElance.txt");
	
	for(String pasta:nomePastas){
		diretorio = new File("htmls"+separador+pasta);
		String[] nomeArquivos = diretorio.list();
	    for(String arquivo:nomeArquivos){
		    printWriter.println(arquivo);
		    printWriter.print(processador.processe("htmls"+separador+pasta+separador+arquivo));    
		}
	}
	
	printWriter.flush();
	printWriter.close();

}



}