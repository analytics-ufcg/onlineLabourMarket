import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class ProcessaArquivo {

	public String processe(String arquivo) throws IOException{
		Scanner arq = new Scanner(new File(arquivo));
		String linha;
		String ultimo = "";
		String retorno = "";
		String tab = "\t";
		while(arq.hasNext()){
            linha = arq.nextLine();
            if(linha.contains("inviteId=")){
            	String[] partes = linha.split("inviteId=");
            	String[] resultado = partes[1].split("&");
            	if(!resultado[0].equals(ultimo)){
            		ultimo = resultado[0];
					retorno = retorno + tab + resultado[0]+"\n";
            	}
            }
		}
		
		return retorno;
		
	}
}
